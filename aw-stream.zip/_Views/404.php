<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="lolkittens" />

	<title>404 Error Page </title>
</head>

<body>

<h1><strong>404 ! </strong>Page not found !</h1>

</body>
</html>