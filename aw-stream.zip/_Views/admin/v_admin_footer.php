  <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    

    <!-- Morris Charts JavaScript -->
    <script src="<?= AdminResourcesDirectory; ?>js/plugins/morris/raphael.min.js"></script>
    <script src="<?= AdminResourcesDirectory; ?>js/plugins/morris/morris.min.js"></script>
    <script src="<?= AdminResourcesDirectory; ?>js/plugins/morris/morris-data.js"></script>

</body>

</html>